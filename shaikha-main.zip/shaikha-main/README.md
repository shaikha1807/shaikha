
# painting with AI

Final project for the Building AI Course 

## Summary

The project about NLP = Natural Language Processing and NLP projects for the arabic language in particular are very important projects , because there are not many of them an open source that can serve the arab software community .


## Problems it will solve

spelling mistakes rather, from the point of view  of logical errors, such as understanding the singular and plural, the past, the presentand and  the imperative, Words are similar in structure but have different meanings . In the sentence, This field of research will never end, and it is extremly important 


## How to used?

These and other NLP techniques are used in a wide range of applications; Researchers use them to analyze scientific articles to speed scientific discovery, to develop more nimble chatbots, and to design an argumentative system capable of formulating logical arguments. In addition to its uses in semantic research, sentiment analysis, speech recognition, playwriting, dialect recognition, and others



## What next ?

Spelling ambiguity and morphological richness and Limitations of scientific research in the field of Arabic language processing 


## Missing from this template 

* more formating options: code blocks 
* how to add files, images, code

## Acknowledgments
https://technologyreview.ae/%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA-%D8%B0%D9%83%D8%A7%D8%A1-%D8%A7%D8%B5%D8%B7%D9%86%D8%A7%D8%B9%D9%8A-%D9%88%D8%A7%D9%84%D9%84%D8%BA%D8%A9-%D8%A7%D9%84%D8%B9%D8%B1%D8%A8%D9%8A%D8%A9/


